import LoginForm from './LoginForm.vue'
import TelephoneCodeForm from './TelephoneCodeForm.vue'

export { LoginForm, TelephoneCodeForm }

import ImageCropping from './src/ImageCropping.vue'

export { ImageCropping }

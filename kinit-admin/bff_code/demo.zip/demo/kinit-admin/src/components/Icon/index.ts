import Icon from './src/Icon.vue'

export type { IconTypes } from './src/types'

export { Icon }

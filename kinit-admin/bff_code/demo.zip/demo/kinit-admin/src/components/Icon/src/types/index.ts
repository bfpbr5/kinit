export interface IconTypes {
  size?: number
  color?: string
  icon: string
  hoverColor?: string
}

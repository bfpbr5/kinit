import ConfigGlobal from './src/ConfigGlobal.vue'

export type { ConfigGlobalTypes } from './src/types'

export { ConfigGlobal }

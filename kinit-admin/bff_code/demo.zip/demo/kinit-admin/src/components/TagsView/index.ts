import TagsView from './src/TagsView.vue'

export { TagsView }

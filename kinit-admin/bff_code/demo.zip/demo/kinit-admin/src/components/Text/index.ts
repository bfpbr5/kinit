import Text from './src/Text.vue'

export { Text }

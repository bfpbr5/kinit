import Qrcode from './src/Qrcode.vue'

export type { QrcodeLogo } from './src/types'

export { Qrcode }

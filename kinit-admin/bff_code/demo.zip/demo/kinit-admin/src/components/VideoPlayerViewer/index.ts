import VideoPlayerViewer from './src/VideoPlayerViewer.vue'

export { VideoPlayerViewer }

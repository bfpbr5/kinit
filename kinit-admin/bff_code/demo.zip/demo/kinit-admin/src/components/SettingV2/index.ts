import SettingV2 from './src/SettingV2.vue'

export { SettingV2 }

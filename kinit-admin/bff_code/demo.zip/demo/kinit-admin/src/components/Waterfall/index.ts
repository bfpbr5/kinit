import Waterfall from './src/Waterfall.vue'

export { Waterfall }

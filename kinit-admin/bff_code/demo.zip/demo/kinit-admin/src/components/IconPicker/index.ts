import IconPicker from './src/IconPicker.vue'

export { IconPicker }

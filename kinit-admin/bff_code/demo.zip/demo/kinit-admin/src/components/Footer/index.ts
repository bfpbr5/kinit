import Footer from './src/Footer.vue'

export { Footer }

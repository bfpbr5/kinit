import ContentWrap from './src/ContentWrap.vue'

export { ContentWrap }

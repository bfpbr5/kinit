-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2024-02-11 10:11:42
-- 服务器版本： 5.7.43-log
-- PHP 版本： 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `we7_com`
--

-- --------------------------------------------------------

--
-- 表的结构 `ims_suetactix_case_info`
--

CREATE TABLE `ims_suetactix_case_info` (
  `id` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '案件名称',
  `info` text COMMENT '案件描述',
  `analysis` text NOT NULL COMMENT '案情研究',
  `timeline` varchar(2000) NOT NULL DEFAULT '' COMMENT '时间线',
  `relation` varchar(2000) NOT NULL DEFAULT '',
  `cause` varchar(5000) NOT NULL DEFAULT '' COMMENT '案由',
  `claim` varchar(5000) NOT NULL DEFAULT '' COMMENT '诉讼请求',
  `questions` varchar(2000) NOT NULL DEFAULT '' COMMENT '待澄清问题',
  `createtime` int(11) NOT NULL DEFAULT '0',
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operator` varchar(20) NOT NULL,
  `cate_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转储表的索引
--

--
-- 表的索引 `ims_suetactix_case_info`
--
ALTER TABLE `ims_suetactix_case_info`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `ims_suetactix_case_info`
--
ALTER TABLE `ims_suetactix_case_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

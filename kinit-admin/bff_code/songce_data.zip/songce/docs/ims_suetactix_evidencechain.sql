-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2024-02-11 10:12:31
-- 服务器版本： 5.7.43-log
-- PHP 版本： 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `we7_com`
--

-- --------------------------------------------------------

--
-- 表的结构 `ims_suetactix_evidencechain`
--

CREATE TABLE `ims_suetactix_evidencechain` (
  `id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL DEFAULT '0' COMMENT '案件ID',
  `evidence_chain` text NOT NULL COMMENT '证据链内容',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `evidence_type` varchar(20) NOT NULL COMMENT '证据类型'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转储表的索引
--

--
-- 表的索引 `ims_suetactix_evidencechain`
--
ALTER TABLE `ims_suetactix_evidencechain`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `ims_suetactix_evidencechain`
--
ALTER TABLE `ims_suetactix_evidencechain`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

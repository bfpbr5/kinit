import request from '@/config/axios'

export const PostCaseAnalysis = (dataId: number, data: any): Promise<IResponse> => {
  return request.post({ url: `/case/analysis/${dataId}`, data })
}

export const PostExplainAnalysis = (): Promise<IResponse> => {
  return request.post({ url: '/case/explain/analysis' })
}

export const PostVerifyAnalysis = (): Promise<IResponse> => {
  return request.post({ url: '/case/verify/analysis' })
}

export const PostChainOfEvidenceAnalysis = (dataId: number): Promise<IResponse> => {
  return request.post({ url: `/case/chain/of/evidence/generate/${dataId}` })
}

export const PostCreateCase = (data: any): Promise<IResponse> => {
  return request.post({ url: '/case/create', data })
}

import Permission from './src/Permission.vue'
import { hasPermi } from './src/utils'

export { Permission, hasPermi }

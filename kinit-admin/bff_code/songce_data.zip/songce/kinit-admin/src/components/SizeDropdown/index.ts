import SizeDropdown from './src/SizeDropdown.vue'

export { SizeDropdown }

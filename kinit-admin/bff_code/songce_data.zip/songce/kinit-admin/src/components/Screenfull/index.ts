import Screenfull from './src/Screenfull.vue'

export { Screenfull }

import Error from './src/Error.vue'

export { Error }

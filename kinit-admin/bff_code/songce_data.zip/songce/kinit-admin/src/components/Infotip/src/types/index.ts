export interface InfoTipSchema {
  label: string
  keys?: string[]
}

import Infotip from './src/Infotip.vue'

export type { InfoTipSchema } from './src/types'

export { Infotip }

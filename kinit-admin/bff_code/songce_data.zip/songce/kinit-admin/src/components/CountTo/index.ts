import CountTo from './src/CountTo.vue'

export { CountTo }

import Collapse from './src/Collapse.vue'

export { Collapse }

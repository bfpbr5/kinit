import Backtop from './src/Backtop.vue'

export { Backtop }

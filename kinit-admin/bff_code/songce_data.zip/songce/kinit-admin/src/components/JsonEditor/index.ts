import JsonEditor from './src/JsonEditor.vue'
export type { JsonEditorProps } from './src/types'

export { JsonEditor }

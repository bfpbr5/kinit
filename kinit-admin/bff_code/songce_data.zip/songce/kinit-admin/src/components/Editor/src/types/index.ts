export type InsertImageType = (url: string, alt: string, href: string) => void

export type InsertVideoType = (url: string, poster: string) => void

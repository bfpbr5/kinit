import { ComponentSize } from 'element-plus'

export interface ConfigGlobalTypes {
  size?: ComponentSize
}

import LocaleDropdown from './src/LocaleDropdown.vue'

export type { Language, LocaleDropdownType } from './src/types'

export { LocaleDropdown }
